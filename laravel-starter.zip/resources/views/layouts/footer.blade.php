<footer class="bg-white border-t text-center py-4 text-sm text-gray-600">
    © {{ date('Y') }} Laravel. All rights reserved.<br>
    Created by Shobhnath
</footer>
